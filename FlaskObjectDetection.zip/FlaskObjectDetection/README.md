# FlaskObjectDetection - TensorFlow

[![](images/logo.png)](https://www.tensorflow.org/)

## Using

<p align="center">
  <img src="images/image3.png" width="350"/>
  <img src="images/image4.png" width="350"/>
</p>

<p align="center">
  <img src="images/image5.png" width="350"/>
  <img src="images/image6.png" width="350"/>
</p>

## Tests

<p align="center">
  <img src="tests/fiesta.jpg" width="350"/>
  <img src="uploads/fiesta.jpg" width="350"/>
</p>